﻿this is a README of python-version MAnorm command tool
if you has any question, you could contact us by email: gzhsss2@gmail.com

Input:
There are four input files needed, 2 peaks files and 2 reads files:
    python MAnorm.py --p1 peak1 --r1 read1 --p2 peak2 --r2 read1

Note:peak file support bed format and macs output xls format. The first three columns 
should be ‘chr start end’ , if there are summit column, should put it in fourth cloumn.

Other Options:
Note: Using --help for seeing details.